# CodeAlpha Robotics & Automation Internship

**Intern:** Khushvir Singh
**Program:** CodeAlpha Robotics & Automation Internship
**Period:** April 2026

---

## Repository Structure

```
codealpha-robotics/
├── task1-research-report/
│   └── README.md                  ← Full research report (Autonomous Vehicles & Drones)
└── task2-robotic-arm-simulation/
    ├── index.html                 ← Live 4-DOF robotic arm simulation
    └── README.md                  ← Technical documentation
```

---

## Tasks

### Task 1 — Research Report: Robotics Applications in Autonomous Vehicles & Drones
A comprehensive research report covering the technical foundations, industry deployments, challenges, and future trends of autonomous vehicles and unmanned aerial vehicles (drones).

**Key topics:** LiDAR/sensor fusion · SLAM · SAE automation levels · Waymo/Tesla/Baidu · drone delivery · precision agriculture · UAM · V2X

→ [Read the Report](task1-research-report/README.md)

---

### Task 2 — Robotic Arm Simulation (4-DOF Interactive)
A fully interactive 2D browser-based simulation of a 4-Degree-of-Freedom planar robotic arm with forward kinematics and automated pick-and-place motion sequence.

**Features:** Real-time FK · 4 joint sliders · 9-step pick-and-place automation · gripper open/close · workspace boundary · cycle counter

→ [View Simulation](task2-robotic-arm-simulation/index.html) | [Documentation](task2-robotic-arm-simulation/README.md)

---

## How to Run the Simulation

No installation required. Open directly in any modern browser:

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/codealpha-robotics.git
cd codealpha-robotics/task2-robotic-arm-simulation

# Open in browser (any of these)
open index.html          # macOS
start index.html         # Windows
xdg-open index.html      # Linux
```

Or just double-click `index.html` in your file explorer.

---

## Technologies Used

| Task | Technology |
|------|-----------|
| Task 1 | Markdown, academic research |
| Task 2 | HTML5 Canvas, Vanilla JavaScript, CSS3 |

---

## References

See individual task READMEs for full reference lists.

---

*Submitted as part of the CodeAlpha Robotics & Automation Internship Program, April 2026.*
