# Task 2 — Robotic Arm Simulation (4-DOF Interactive)

**Intern:** Khushvir Singh — CodeAlpha Robotics & Automation Internship
**Simulation Type:** 2D Interactive Planar Arm (4-DOF)
**Date:** April 2026

---

## Live Demo

Open `index.html` directly in any modern browser — no server or dependencies required.

---

## Overview

An interactive 2D browser-based simulation of a **4-Degree-of-Freedom planar robotic arm** built with HTML5 Canvas + Vanilla JavaScript. Demonstrates core robotics concepts:

- Degrees of freedom (DOF)
- Forward kinematics (FK)
- Joint-space control
- Automated pick-and-place motion sequence with smooth trajectory interpolation

---

## System Design

### Physical Configuration

| Joint | Range | Link Length | Role |
|-------|-------|-------------|------|
| J1 — Base rotation | −150° to +150° | — | Rotates full arm around mount |
| J2 — Shoulder | −160° to +160° | 110 px | Controls upper-arm elevation |
| J3 — Elbow | −160° to +160° | 95 px | Bends forearm relative to upper arm |
| J4 — Wrist | −150° to +150° | 80 px | Orients end-effector |
| EE — Gripper | open/close | 50 px | Parallel jaw gripper |

**Total DOF:** 4 (all revolute joints)
**Maximum reach:** 110 + 95 + 80 + 50 = **335 px** from base origin

### Coordinate System

- Origin (0, 0) at the base joint
- Positive X extends right, positive Y extends upward
- J1 angle is absolute from global X-axis; J2–J4 are relative to the previous link

---

## Forward Kinematics

For a planar serial chain, each joint position is computed by accumulating rotations:

```
φᵢ = φᵢ₋₁ + θᵢ          (cumulative angle)
Pᵢ.x = Pᵢ₋₁.x + Lᵢ · cos(φᵢ)
Pᵢ.y = Pᵢ₋₁.y + Lᵢ · sin(φᵢ)
```

### FK Implementation

```javascript
function fk(joints) {
  const L = [110, 95, 80, 50];  // link lengths in px
  let x = BASE.x, y = BASE.y;
  let angle = joints[0] * PI/180 - PI/2;
  const pts = [{x, y}];
  for (let i = 0; i < 4; i++) {
    if (i > 0) angle += joints[i] * PI/180;
    x += L[i] * Math.cos(angle);
    y += L[i] * Math.sin(angle);
    pts.push({x, y});
  }
  return pts;  // array of 5 joint positions [base → EE]
}
```

### Workspace

| Parameter | Value | Notes |
|-----------|-------|-------|
| Max reach (R_max) | 335 px | Full arm extension |
| Min reach (R_min) | ~0 px | Arm fully folded |
| J1 sweep | 300° | ±150° from home |
| Workspace type | Partial annulus | Limited by joint stops |

---

## Pick-and-Place Automation Sequence

The automated cycle mimics an industrial robot transferring an object from a pick zone (left) to a place zone (right) in 9 keyframe states.

| # | Phase | θ1 | θ2 | θ3 | θ4 | Grip |
|---|-------|----|----|----|----|------|
| 1 | Home position | 0° | 45° | −90° | 0° | Open |
| 2 | Approach pick zone | −45° | 60° | −80° | −10° | Open |
| 3 | Descend to object | −45° | 80° | −50° | −30° | Open |
| 4 | Grip close | −45° | 80° | −50° | −30° | **Closed** |
| 5 | Lift with object | −45° | 55° | −80° | −10° | Closed |
| 6 | Travel to place zone | 45° | 60° | −80° | 10° | Closed |
| 7 | Descend to deposit | 45° | 80° | −50° | 30° | Closed |
| 8 | Release object | 45° | 80° | −50° | 30° | **Open** |
| 9 | Return to home | 0° | 45° | −90° | 0° | Open |

### Interpolation Method

Ease-in-out quadratic function (mimics industrial S-curve velocity profiles):

```javascript
function easeInOut(t) {
  return t < 0.5 ? 2*t*t : 1 - Math.pow(-2*t + 2, 2) / 2;
}

function angleLerp(a, b, t) {
  let delta = ((b - a) % 360 + 540) % 360 - 180;  // shortest arc
  return a + delta * easeInOut(t);
}
```

---

## Features

- 4 independently controllable revolute joints (J1–J4) via sliders
- Real-time forward kinematics with live end-effector coordinate display
- Dashed workspace boundary circle (max reach visualisation)
- Automated 9-step pick-and-place cycle with keyframe animation
- Gripper open/close state with visual jaw aperture change
- Object pickup and deposit with colour change on successful placement
- Cycle counter tracking completed pick-and-place operations
- Status indicator: Idle / Moving / Grabbed / Done

---

## Technology Stack

| Component | Technology |
|-----------|-----------|
| Rendering | HTML5 Canvas 2D API (60 fps) |
| Kinematics | Vanilla JavaScript |
| Animation | `requestAnimationFrame` loop |
| UI Controls | HTML `<input type="range">` sliders |
| Dependencies | None — runs in any browser |

---

## Possible Extensions

- **Inverse kinematics (IK):** Compute joint angles from target (x, y) using FABRIK or Jacobian pseudo-inverse
- **Collision detection:** Self-collision and workspace obstacle avoidance
- **Torque & dynamics:** Link mass/inertia and actuator torque simulation
- **3D simulation:** Extend to 6-DOF spatial arm using Three.js / WebGL with DH parameters
- **Path planning:** Cartesian straight-line path following between waypoints
- **ROS integration:** Export joint state messages to ROS topics for Gazebo or physical hardware

---

## References

1. Craig, J. J. (2005). *Introduction to Robotics: Mechanics and Control* (3rd ed.). Pearson.
2. Spong, M. W., Hutchinson, S., & Vidyasagar, M. (2020). *Robot Modeling and Control* (2nd ed.). Wiley.
3. Denavit, J., & Hartenberg, R. S. (1955). A kinematic notation for lower-pair mechanisms. *ASME Journal of Applied Mechanics, 22*, 215–221.
4. Siciliano, B. et al. (2009). *Robotics: Modelling, Planning and Control.* Springer.
5. MDN Web Docs (2025). CanvasRenderingContext2D. https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API
6. CodeAlpha (2026). Robotics & Automation Internship Task List. https://www.codealpha.tech
